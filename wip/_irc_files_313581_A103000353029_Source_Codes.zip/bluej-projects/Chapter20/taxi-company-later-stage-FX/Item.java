/**
 * An item in the city.
 * 
 * @author David J. Barnes and Michael Kölling
 * @version 7.2
 */

public interface Item
{
    Location getLocation();
}
