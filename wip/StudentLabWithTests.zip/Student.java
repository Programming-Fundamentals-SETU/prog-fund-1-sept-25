public class Student {
    private String name;
    private String id;
    private int mark;

    public Student(String name, String id, int mark) {
        this.name = name;
        this.id = id;
        this.mark = 0; // ❌ Bug: ignores the mark parameter
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return name; // ❌ Bug: should return id
    }

    public int getMark() {
        return mark;
    }

    public void setMark(int newMark) {
        newMark = mark; // ❌ Bug: reverses assignment
    }

    public boolean isPassing() {
        return mark > 50; // ❌ Bug: fails at 50 exactly
    }
}
