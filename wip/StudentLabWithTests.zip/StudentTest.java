import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class StudentTest {
    private Student alice;
    private Student bob;

    @Before
    public void setUp() {
        alice = new Student("Alice", "A001", 75);
        bob = new Student("Bob", "B002", 45);
    }

    @Test
    public void testGetName() {
        assertEquals("Alice", alice.getName());
    }

    @Test
    public void testGetId() {
        assertEquals("A001", alice.getId());
    }

    @Test
    public void testGetMark() {
        assertEquals(75, alice.getMark());
    }

    @Test
    public void testSetMark() {
        bob.setMark(60);
        assertEquals(60, bob.getMark());
    }

    @Test
    public void testIsPassing() {
        assertTrue(alice.isPassing());
        assertFalse(bob.isPassing());

        Student boundary = new Student("Charlie", "C003", 50);
        assertTrue(boundary.isPassing());
    }
}
