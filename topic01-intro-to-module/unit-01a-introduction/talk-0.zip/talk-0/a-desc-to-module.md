Module Description and Assessment Details


This document describes the module and how we will approach it

